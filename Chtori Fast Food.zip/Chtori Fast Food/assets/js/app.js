// Chtori Fast Food - app behaviors

const preloader = document.getElementById('preloader');
window.addEventListener('load', () => {
  setTimeout(() => preloader.classList.add('hidden'), 650);
});

const revealItems = document.querySelectorAll('.reveal');
const revealObserver = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        revealObserver.unobserve(entry.target);
      }
    });
  },
  { threshold: 0.14 }
);
revealItems.forEach((item) => revealObserver.observe(item));

const counters = document.querySelectorAll('[data-count]');
counters.forEach((counter) => {
  const target = parseFloat(counter.getAttribute('data-count'));
  const suffix = Number.isInteger(target) ? '' : '.';
  let current = 0;
  const step = target / 70;
  const update = () => {
    current += step;
    if (current < target) {
      counter.textContent = Number.isInteger(target) ? Math.round(current) : current.toFixed(1);
      requestAnimationFrame(update);
    } else {
      counter.textContent = target.toFixed(target % 1 === 0 ? 0 : 1);
    }
  };
  update();
});

const backToTop = document.querySelector('.back-to-top');
window.addEventListener('scroll', () => {
  backToTop.classList.toggle('show', window.scrollY > 520);
});
backToTop.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));

document.querySelectorAll('.faq-item').forEach((item) => {
  item.addEventListener('click', () => {
    item.classList.toggle('active');
  });
});

const glow = document.querySelector('.cursor-glow');
window.addEventListener('mousemove', (event) => {
  glow.style.left = `${event.clientX}px`;
  glow.style.top = `${event.clientY}px`;
});

document.querySelectorAll('.btn, .nav-cta, .float-btn, .category-card, .dish-card, .menu-card, .gallery-card, .review-card').forEach((el) => {
  el.addEventListener('mousemove', (e) => {
    const rect = el.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    el.style.setProperty('--mouse-x', `${x}px`);
    el.style.setProperty('--mouse-y', `${y}px`);
  });
});

