# Chtori Fast Food

## File structure
- `index.html` - main HTML entry
- `assets/css/style.css` - styles
- `assets/js/app.js` - JavaScript behavior

## Run
- Easiest: open `index.html` in a browser.
- If using WAMP/XAMPP: put the folder under your `www` directory and open the page via the local server URL.

